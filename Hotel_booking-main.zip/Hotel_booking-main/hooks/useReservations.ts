
import { useContext } from 'react';
import { ReservationsContext } from '../context/ReservationsContext';

export const useReservations = () => {
  const context = useContext(ReservationsContext);
  if (context === undefined) {
    throw new Error('useReservations must be used within a ReservationsProvider');
  }
  return context;
};
