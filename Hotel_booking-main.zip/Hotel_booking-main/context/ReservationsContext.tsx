import React, { createContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { Reservation, ReservationStatus } from '../types';
import * as api from '../services/apiService';
import { TOTAL_TABLES } from '../constants';

interface ReservationsContextType {
  reservations: Reservation[];
  loading: boolean;
  error: string | null;
  addReservation: (newReservationData: Omit<Reservation, 'id' | 'status'>) => Promise<Reservation>;
  updateReservationStatus: (id: string, status: ReservationStatus) => Promise<void>;
  deleteReservation: (id: string) => Promise<void>;
  refetchReservations: () => Promise<void>;
  getAvailableTablesForSlot: (date: string, time: string) => number;
}

export const ReservationsContext = createContext<ReservationsContextType | undefined>(undefined);

interface ReservationsProviderProps {
  children: ReactNode;
}

export const ReservationsProvider: React.FC<ReservationsProviderProps> = ({ children }) => {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchReservations = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.fetchReservations();
      setReservations(data);
    } catch (err) {
      setError('Failed to fetch reservations.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchReservations();
  }, [fetchReservations]);

  const addReservation = async (newReservationData: Omit<Reservation, 'id' | 'status'>): Promise<Reservation> => {
    try {
      const newReservation = await api.addReservation(newReservationData);
      setReservations(prev => [...prev, newReservation]);
      return newReservation;
    } catch (err) {
      console.error('Failed to add reservation', err);
      throw new Error('Could not add reservation.');
    }
  };

  const updateReservationStatus = async (id: string, status: ReservationStatus): Promise<void> => {
    try {
      const updatedReservation = await api.updateReservationStatus(id, status);
      setReservations(prev =>
        prev.map(res => (res.id === id ? updatedReservation : res))
      );
    } catch (err) {
      console.error('Failed to update reservation status', err);
      throw new Error('Could not update reservation status.');
    }
  };

  const deleteReservation = async (id: string): Promise<void> => {
    try {
      await api.deleteReservation(id);
      setReservations(prev => prev.filter(res => res.id !== id));
    } catch (err) {
      console.error('Failed to delete reservation', err);
      throw new Error('Could not delete reservation.');
    }
  };

  const getAvailableTablesForSlot = (date: string, time: string): number => {
    const tablesInUse = api.getTablesInUse(reservations, date, time);
    return TOTAL_TABLES - tablesInUse;
  };

  const value = {
    reservations,
    loading,
    error,
    addReservation,
    updateReservationStatus,
    deleteReservation,
    refetchReservations: fetchReservations,
    getAvailableTablesForSlot,
  };

  return (
    <ReservationsContext.Provider value={value}>
      {children}
    </ReservationsContext.Provider>
  );
};