import { GoogleGenAI } from "@google/genai";
import { Reservation } from '../types';
import { RESTAURANT_NAME, RESTAURANT_ADDRESS } from '../constants';

// Fix: Per coding guidelines, initialize with apiKey object and use process.env.API_KEY directly.
// The user is responsible for setting this up. Assume the variable is pre-configured and valid.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const generateConfirmationMessage = async (reservation: Reservation): Promise<string> => {
  const prompt = `
    You are a friendly and professional assistant for a restaurant called "${RESTAURANT_NAME}".
    Your task is to generate a booking confirmation message.
    The message should be warm, welcoming, and confirm all the details of the reservation.
    Do not add any preamble like "Here is the message:". Just output the message directly.
    
    Here are the booking details:
    - Customer Name: ${reservation.name}
    - Number of Guests: ${reservation.guests}
    - Date: ${reservation.date}
    - Time: ${reservation.time}
    
    Include the restaurant's name and address in the message.
    Restaurant Address: ${RESTAURANT_ADDRESS}
    
    Keep the message concise and suitable for SMS, WhatsApp, or email. End with a friendly closing.
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text.trim();
  } catch (error) {
    console.error("Error generating confirmation message:", error);
    // Fallback message in case of API error, which is good practice.
    return `Dear ${reservation.name},\n\nThis is a confirmation for your booking at ${RESTAURANT_NAME} for ${reservation.guests} guest(s) on ${reservation.date} at ${reservation.time}. We are excited to welcome you!\n\nOur address: ${RESTAURANT_ADDRESS}`;
  }
};
