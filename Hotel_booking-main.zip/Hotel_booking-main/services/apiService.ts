import { Reservation, ReservationStatus, AdminUser, UserRole } from '../types';
import { TOTAL_TABLES, RESERVATION_DURATION_HOURS } from '../constants';

const RESERVATIONS_STORAGE_KEY = 'restaurantReservations';
const ADMIN_USERS_KEY = 'restaurantAdmins';

// --- Helper Functions ---

const getFromStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultValue;
  } catch (error) {
    console.error(`Failed to parse ${key} from localStorage`, error);
    return defaultValue;
  }
};

const saveToStorage = (key: string, data: any): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Failed to save ${key} to localStorage`, error);
  }
};

// --- Initial Data Seeding ---

const initializeReservationData = () => {
  if (localStorage.getItem(RESERVATIONS_STORAGE_KEY) === null) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];
    const seedData: Reservation[] = [
      { id: 'seed-1', name: 'John Doe', phone: '123-456-7890', guests: 2, date: tomorrowStr, time: '19:00', status: ReservationStatus.Confirmed },
      { id: 'seed-2', name: 'Jane Smith', phone: '234-567-8901', guests: 4, date: tomorrowStr, time: '19:30', status: ReservationStatus.Pending },
    ];
    saveToStorage(RESERVATIONS_STORAGE_KEY, seedData);
  }
};

const initializeAdminData = () => {
  if (localStorage.getItem(ADMIN_USERS_KEY) === null) {
    const seedAdmins: AdminUser[] = [
      // In a real app, passwords would be securely hashed server-side.
      // Here we simulate it for demonstration.
      { username: 'admin', passwordHash: 'password', role: 'admin' },
      { username: 'nikhil@gmail.com', passwordHash: 'Admin', role: 'superadmin' },
    ];
    saveToStorage(ADMIN_USERS_KEY, seedAdmins);
  }
};

initializeReservationData();
initializeAdminData();

// --- Reservation API Functions ---

export const fetchReservations = async (): Promise<Reservation[]> => {
  await new Promise(resolve => setTimeout(resolve, 500));
  return getFromStorage<Reservation[]>(RESERVATIONS_STORAGE_KEY, []);
};

export const addReservation = async (newData: Omit<Reservation, 'id' | 'status'>): Promise<Reservation> => {
  await new Promise(resolve => setTimeout(resolve, 500));
  const reservations = getFromStorage<Reservation[]>(RESERVATIONS_STORAGE_KEY, []);
  const newReservation: Reservation = {
    ...newData,
    id: `res-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
    status: ReservationStatus.Pending,
  };
  saveToStorage(RESERVATIONS_STORAGE_KEY, [...reservations, newReservation]);
  return newReservation;
};

export const updateReservationStatus = async (id: string, status: ReservationStatus): Promise<Reservation> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  const reservations = getFromStorage<Reservation[]>(RESERVATIONS_STORAGE_KEY, []);
  const reservationIndex = reservations.findIndex(r => r.id === id);
  if (reservationIndex === -1) throw new Error('Reservation not found');
  reservations[reservationIndex].status = status;
  saveToStorage(RESERVATIONS_STORAGE_KEY, reservations);
  return reservations[reservationIndex];
};

export const deleteReservation = async (id: string): Promise<void> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  let reservations = getFromStorage<Reservation[]>(RESERVATIONS_STORAGE_KEY, []);
  const updatedReservations = reservations.filter(r => r.id !== id);
  if (reservations.length === updatedReservations.length) throw new Error('Reservation not found');
  saveToStorage(RESERVATIONS_STORAGE_KEY, updatedReservations);
};

export const getTablesInUse = (reservations: Reservation[], date: string, time: string): number => {
    const selectedDateTime = new Date(`${date}T${time}:00`).getTime();
    const reservationWindow = RESERVATION_DURATION_HOURS * 60 * 60 * 1000;
    const activeReservations = reservations.filter(res => {
        if (res.date !== date || res.status === ReservationStatus.Cancelled || res.status === ReservationStatus.Completed) return false;
        const resDateTime = new Date(`${res.date}T${res.time}:00`).getTime();
        const newEndTime = selectedDateTime + reservationWindow;
        const existingEndTime = resDateTime + reservationWindow;
        return selectedDateTime < existingEndTime && resDateTime < newEndTime;
    });
    return activeReservations.reduce((acc, curr) => acc + Math.ceil(curr.guests / 4), 0);
};

// --- Admin User API Functions ---

export const authenticateUser = async (username: string, password: string): Promise<{ role: UserRole } | null> => {
  await new Promise(resolve => setTimeout(resolve, 500));
  const users = getFromStorage<AdminUser[]>(ADMIN_USERS_KEY, []);
  const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
  // NOTE: This is a direct password comparison, ONLY for demo purposes.
  // A real application MUST use a secure hashing and verification algorithm (e.g., bcrypt).
  if (user && user.passwordHash === password) {
    return { role: user.role };
  }
  return null;
};

export const registerAdmin = async (username: string, password: string): Promise<AdminUser> => {
  await new Promise(resolve => setTimeout(resolve, 500));
  const users = getFromStorage<AdminUser[]>(ADMIN_USERS_KEY, []);
  const existingUser = users.find(u => u.username.toLowerCase() === username.toLowerCase());
  if (existingUser) {
    throw new Error('Username already exists.');
  }
  const newUser: AdminUser = {
    username,
    passwordHash: password, // Again, plain text for demo only.
    role: 'admin',
  };
  saveToStorage(ADMIN_USERS_KEY, [...users, newUser]);
  return newUser;
};

export const getAllAdmins = async (): Promise<AdminUser[]> => {
  await new Promise(resolve => setTimeout(resolve, 500));
  return getFromStorage<AdminUser[]>(ADMIN_USERS_KEY, []);
};
