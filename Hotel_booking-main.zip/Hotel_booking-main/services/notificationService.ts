import { Reservation } from '../types';

export interface NotificationPrefs {
  sms: boolean;
  email: boolean;
  whatsapp: boolean;
}

/**
 * Simulates sending notifications via different channels.
 * In a real application, this would make API calls to services like Twilio, SendGrid, etc.
 * @param reservation The reservation details.
 * @param prefs The user's notification preferences.
 * @param message The AI-generated message to send.
 */
export const sendNotifications = async (
  reservation: Reservation,
  prefs: NotificationPrefs,
  message: string
): Promise<void> => {
  console.log(`
-----------------------------------------
Initiating notifications for ${reservation.name}...
Preferences: ${JSON.stringify(prefs)}
-----------------------------------------
  `);

  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  if (prefs.sms) {
    // In a real app: await twilio.messages.create({ to: reservation.phone, body: message, ... })
    console.log(`✅ [SMS SENT] to ${reservation.phone}`);
    console.log(`   Message: "${message}"`);
  }

  if (prefs.email) {
    // In a real app: await sendgrid.send({ to: userEmail, subject: 'Your Reservation is Confirmed!', html: message, ... })
    const dummyEmail = `${reservation.name.split(' ')[0].toLowerCase()}@example.com`;
    console.log(`✅ [EMAIL SENT] to ${dummyEmail}`);
    console.log(`   Message: "${message}"`);
  }

  if (prefs.whatsapp) {
    // In a real app: await whatsappApi.sendMessage({ to: reservation.phone, body: message, ... })
    console.log(`✅ [WHATSAPP SENT] to ${reservation.phone}`);
    console.log(`   Message: "${message}"`);
  }
  
  console.log(`
-----------------------------------------
Notification dispatch complete.
-----------------------------------------
  `);
};
